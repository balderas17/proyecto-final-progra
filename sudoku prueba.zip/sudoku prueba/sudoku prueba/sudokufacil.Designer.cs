﻿namespace sudoku_prueba
{
    partial class sudokufacil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            textBox12 = new TextBox();
            textBox11 = new TextBox();
            textBox10 = new TextBox();
            textBox9 = new TextBox();
            textBox8 = new TextBox();
            textBox7 = new TextBox();
            textBox1 = new TextBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label4 = new Label();
            textBox6 = new TextBox();
            label1 = new Label();
            lblinstrucciones = new Label();
            btnValidar = new Button();
            btnResolver = new Button();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 49.5412827F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50.4587173F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 53F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 53F));
            tableLayoutPanel1.Controls.Add(textBox12, 1, 3);
            tableLayoutPanel1.Controls.Add(textBox11, 2, 2);
            tableLayoutPanel1.Controls.Add(textBox10, 1, 2);
            tableLayoutPanel1.Controls.Add(textBox9, 0, 2);
            tableLayoutPanel1.Controls.Add(textBox8, 3, 1);
            tableLayoutPanel1.Controls.Add(textBox7, 0, 1);
            tableLayoutPanel1.Controls.Add(textBox1, 0, 0);
            tableLayoutPanel1.Controls.Add(textBox5, 3, 2);
            tableLayoutPanel1.Controls.Add(textBox4, 1, 1);
            tableLayoutPanel1.Controls.Add(textBox2, 2, 3);
            tableLayoutPanel1.Controls.Add(textBox3, 2, 1);
            tableLayoutPanel1.Controls.Add(label3, 3, 0);
            tableLayoutPanel1.Controls.Add(label2, 0, 3);
            tableLayoutPanel1.Controls.Add(label4, 3, 3);
            tableLayoutPanel1.Controls.Add(textBox6, 2, 0);
            tableLayoutPanel1.Controls.Add(label1, 1, 0);
            tableLayoutPanel1.Location = new Point(281, 89);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 4;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 52.5252533F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 47.4747467F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 48F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
            tableLayoutPanel1.Size = new Size(216, 201);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // textBox12
            // 
            textBox12.Font = new Font("Segoe UI", 27F);
            textBox12.Location = new Point(57, 153);
            textBox12.Multiline = true;
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(48, 45);
            textBox12.TabIndex = 15;
            textBox12.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox11
            // 
            textBox11.Font = new Font("Segoe UI", 27F);
            textBox11.Location = new Point(112, 105);
            textBox11.Multiline = true;
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(47, 42);
            textBox11.TabIndex = 14;
            textBox11.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox10
            // 
            textBox10.Font = new Font("Segoe UI", 27F);
            textBox10.Location = new Point(57, 105);
            textBox10.Multiline = true;
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(48, 42);
            textBox10.TabIndex = 13;
            textBox10.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox9
            // 
            textBox9.Font = new Font("Segoe UI", 27F);
            textBox9.Location = new Point(3, 105);
            textBox9.Multiline = true;
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(48, 42);
            textBox9.TabIndex = 12;
            textBox9.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            textBox8.Font = new Font("Segoe UI", 27F);
            textBox8.Location = new Point(165, 57);
            textBox8.Multiline = true;
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(48, 42);
            textBox8.TabIndex = 11;
            textBox8.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            textBox7.Font = new Font("Segoe UI", 27F);
            textBox7.Location = new Point(3, 57);
            textBox7.Multiline = true;
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(48, 42);
            textBox7.TabIndex = 10;
            textBox7.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 27F);
            textBox1.Location = new Point(3, 3);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(48, 48);
            textBox1.TabIndex = 0;
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Segoe UI", 27F);
            textBox5.Location = new Point(165, 105);
            textBox5.Multiline = true;
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(48, 42);
            textBox5.TabIndex = 4;
            textBox5.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Segoe UI", 27F);
            textBox4.Location = new Point(57, 57);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(48, 42);
            textBox4.TabIndex = 3;
            textBox4.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 27F);
            textBox2.Location = new Point(112, 153);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(47, 45);
            textBox2.TabIndex = 1;
            textBox2.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Segoe UI", 27F);
            textBox3.Location = new Point(112, 57);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(47, 42);
            textBox3.TabIndex = 2;
            textBox3.TextAlign = HorizontalAlignment.Center;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(165, 0);
            label3.Name = "label3";
            label3.Size = new Size(42, 50);
            label3.TabIndex = 7;
            label3.Text = "2";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(3, 150);
            label2.Name = "label2";
            label2.Size = new Size(42, 50);
            label2.TabIndex = 6;
            label2.Text = "4";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(165, 150);
            label4.Name = "label4";
            label4.Size = new Size(42, 50);
            label4.TabIndex = 8;
            label4.Text = "3";
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Segoe UI", 27F);
            textBox6.Location = new Point(112, 3);
            textBox6.Multiline = true;
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(47, 47);
            textBox6.TabIndex = 9;
            textBox6.TextAlign = HorizontalAlignment.Center;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(57, 0);
            label1.Name = "label1";
            label1.Size = new Size(42, 50);
            label1.TabIndex = 5;
            label1.Text = "1";
            // 
            // lblinstrucciones
            // 
            lblinstrucciones.AutoSize = true;
            lblinstrucciones.Font = new Font("Segoe UI", 14F);
            lblinstrucciones.Location = new Point(103, 24);
            lblinstrucciones.Name = "lblinstrucciones";
            lblinstrucciones.Size = new Size(561, 50);
            lblinstrucciones.TabIndex = 1;
            lblinstrucciones.Text = "Llene los espacios con numeros del 1 al 4 sin que estos se repitan\r\n en sentido vertical, horizontal y en cada caja de 2x2";
            // 
            // btnValidar
            // 
            btnValidar.Location = new Point(281, 321);
            btnValidar.Name = "btnValidar";
            btnValidar.Size = new Size(113, 31);
            btnValidar.TabIndex = 2;
            btnValidar.Text = "Validar sudoku";
            btnValidar.UseVisualStyleBackColor = true;
            btnValidar.Click += btnValidar_Click;
            // 
            // btnResolver
            // 
            btnResolver.Location = new Point(422, 321);
            btnResolver.Name = "btnResolver";
            btnResolver.Size = new Size(75, 27);
            btnResolver.TabIndex = 3;
            btnResolver.Text = "Resolver";
            btnResolver.UseVisualStyleBackColor = true;
            // 
            // sudokufacil
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnResolver);
            Controls.Add(btnValidar);
            Controls.Add(lblinstrucciones);
            Controls.Add(tableLayoutPanel1);
            Name = "sudokufacil";
            Text = "sudokufacil";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Label lblinstrucciones;
        private Button btnValidar;
        private TextBox textBox1;
        private TextBox textBox3;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textBox12;
        private TextBox textBox11;
        private TextBox textBox10;
        private TextBox textBox9;
        private TextBox textBox8;
        private TextBox textBox7;
        private TextBox textBox6;
        private Button btnResolver;
    }
}