﻿namespace sudoku_prueba
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            textBox12 = new TextBox();
            textBox13 = new TextBox();
            textBox14 = new TextBox();
            textBox15 = new TextBox();
            textBox16 = new TextBox();
            textBox17 = new TextBox();
            textBox18 = new TextBox();
            textBox19 = new TextBox();
            textBox20 = new TextBox();
            textBox21 = new TextBox();
            textBox22 = new TextBox();
            textBox23 = new TextBox();
            textBox24 = new TextBox();
            textBox25 = new TextBox();
            textBox26 = new TextBox();
            textBox27 = new TextBox();
            textBox28 = new TextBox();
            textBox29 = new TextBox();
            textBox30 = new TextBox();
            textBox31 = new TextBox();
            textBox32 = new TextBox();
            textBox33 = new TextBox();
            textBox34 = new TextBox();
            textBox35 = new TextBox();
            textBox36 = new TextBox();
            textBox37 = new TextBox();
            textBox38 = new TextBox();
            textBox39 = new TextBox();
            textBox40 = new TextBox();
            textBox41 = new TextBox();
            textBox42 = new TextBox();
            textBox43 = new TextBox();
            textBox44 = new TextBox();
            textBox45 = new TextBox();
            textBox46 = new TextBox();
            textBox47 = new TextBox();
            textBox48 = new TextBox();
            textBox49 = new TextBox();
            textBox50 = new TextBox();
            textBox51 = new TextBox();
            textBox52 = new TextBox();
            textBox53 = new TextBox();
            textBox54 = new TextBox();
            textBox55 = new TextBox();
            textBox56 = new TextBox();
            textBox57 = new TextBox();
            textBox58 = new TextBox();
            textBox59 = new TextBox();
            textBox60 = new TextBox();
            textBox61 = new TextBox();
            textBox62 = new TextBox();
            textBox63 = new TextBox();
            textBox64 = new TextBox();
            textBox65 = new TextBox();
            textBox66 = new TextBox();
            textBox67 = new TextBox();
            textBox68 = new TextBox();
            textBox69 = new TextBox();
            textBox70 = new TextBox();
            textBox71 = new TextBox();
            textBox72 = new TextBox();
            textBox73 = new TextBox();
            textBox74 = new TextBox();
            textBox75 = new TextBox();
            textBox76 = new TextBox();
            textBox77 = new TextBox();
            textBox78 = new TextBox();
            textBox79 = new TextBox();
            textBox80 = new TextBox();
            textBox81 = new TextBox();
            btnGenerar = new Button();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Outset;
            tableLayoutPanel1.ColumnCount = 9;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.7241383F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 9.885057F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.Controls.Add(textBox81, 8, 8);
            tableLayoutPanel1.Controls.Add(textBox80, 7, 8);
            tableLayoutPanel1.Controls.Add(textBox79, 6, 8);
            tableLayoutPanel1.Controls.Add(textBox78, 5, 8);
            tableLayoutPanel1.Controls.Add(textBox77, 4, 8);
            tableLayoutPanel1.Controls.Add(textBox76, 3, 8);
            tableLayoutPanel1.Controls.Add(textBox75, 2, 8);
            tableLayoutPanel1.Controls.Add(textBox74, 1, 8);
            tableLayoutPanel1.Controls.Add(textBox73, 0, 8);
            tableLayoutPanel1.Controls.Add(textBox72, 8, 7);
            tableLayoutPanel1.Controls.Add(textBox71, 7, 7);
            tableLayoutPanel1.Controls.Add(textBox70, 6, 7);
            tableLayoutPanel1.Controls.Add(textBox69, 5, 7);
            tableLayoutPanel1.Controls.Add(textBox68, 4, 7);
            tableLayoutPanel1.Controls.Add(textBox67, 3, 7);
            tableLayoutPanel1.Controls.Add(textBox66, 2, 7);
            tableLayoutPanel1.Controls.Add(textBox65, 1, 7);
            tableLayoutPanel1.Controls.Add(textBox64, 0, 7);
            tableLayoutPanel1.Controls.Add(textBox63, 8, 6);
            tableLayoutPanel1.Controls.Add(textBox62, 7, 6);
            tableLayoutPanel1.Controls.Add(textBox61, 6, 6);
            tableLayoutPanel1.Controls.Add(textBox60, 5, 6);
            tableLayoutPanel1.Controls.Add(textBox59, 4, 6);
            tableLayoutPanel1.Controls.Add(textBox58, 3, 6);
            tableLayoutPanel1.Controls.Add(textBox57, 2, 6);
            tableLayoutPanel1.Controls.Add(textBox56, 1, 6);
            tableLayoutPanel1.Controls.Add(textBox55, 0, 6);
            tableLayoutPanel1.Controls.Add(textBox54, 8, 5);
            tableLayoutPanel1.Controls.Add(textBox53, 7, 5);
            tableLayoutPanel1.Controls.Add(textBox52, 6, 5);
            tableLayoutPanel1.Controls.Add(textBox51, 5, 5);
            tableLayoutPanel1.Controls.Add(textBox50, 4, 5);
            tableLayoutPanel1.Controls.Add(textBox49, 3, 5);
            tableLayoutPanel1.Controls.Add(textBox48, 2, 5);
            tableLayoutPanel1.Controls.Add(textBox47, 1, 5);
            tableLayoutPanel1.Controls.Add(textBox46, 0, 5);
            tableLayoutPanel1.Controls.Add(textBox45, 8, 4);
            tableLayoutPanel1.Controls.Add(textBox44, 7, 4);
            tableLayoutPanel1.Controls.Add(textBox43, 6, 4);
            tableLayoutPanel1.Controls.Add(textBox42, 5, 4);
            tableLayoutPanel1.Controls.Add(textBox41, 4, 4);
            tableLayoutPanel1.Controls.Add(textBox40, 3, 4);
            tableLayoutPanel1.Controls.Add(textBox39, 2, 4);
            tableLayoutPanel1.Controls.Add(textBox38, 1, 4);
            tableLayoutPanel1.Controls.Add(textBox37, 0, 4);
            tableLayoutPanel1.Controls.Add(textBox36, 8, 3);
            tableLayoutPanel1.Controls.Add(textBox35, 7, 3);
            tableLayoutPanel1.Controls.Add(textBox34, 6, 3);
            tableLayoutPanel1.Controls.Add(textBox33, 5, 3);
            tableLayoutPanel1.Controls.Add(textBox32, 4, 3);
            tableLayoutPanel1.Controls.Add(textBox31, 3, 3);
            tableLayoutPanel1.Controls.Add(textBox30, 2, 3);
            tableLayoutPanel1.Controls.Add(textBox29, 1, 3);
            tableLayoutPanel1.Controls.Add(textBox28, 0, 3);
            tableLayoutPanel1.Controls.Add(textBox27, 8, 2);
            tableLayoutPanel1.Controls.Add(textBox26, 7, 2);
            tableLayoutPanel1.Controls.Add(textBox25, 6, 2);
            tableLayoutPanel1.Controls.Add(textBox24, 5, 2);
            tableLayoutPanel1.Controls.Add(textBox23, 4, 2);
            tableLayoutPanel1.Controls.Add(textBox22, 3, 2);
            tableLayoutPanel1.Controls.Add(textBox21, 2, 2);
            tableLayoutPanel1.Controls.Add(textBox20, 1, 2);
            tableLayoutPanel1.Controls.Add(textBox19, 0, 2);
            tableLayoutPanel1.Controls.Add(textBox18, 8, 1);
            tableLayoutPanel1.Controls.Add(textBox17, 7, 1);
            tableLayoutPanel1.Controls.Add(textBox16, 6, 1);
            tableLayoutPanel1.Controls.Add(textBox15, 5, 1);
            tableLayoutPanel1.Controls.Add(textBox14, 4, 1);
            tableLayoutPanel1.Controls.Add(textBox13, 3, 1);
            tableLayoutPanel1.Controls.Add(textBox12, 2, 1);
            tableLayoutPanel1.Controls.Add(textBox11, 1, 1);
            tableLayoutPanel1.Controls.Add(textBox10, 0, 1);
            tableLayoutPanel1.Controls.Add(textBox9, 8, 0);
            tableLayoutPanel1.Controls.Add(textBox8, 7, 0);
            tableLayoutPanel1.Controls.Add(textBox7, 6, 0);
            tableLayoutPanel1.Controls.Add(textBox6, 5, 0);
            tableLayoutPanel1.Controls.Add(textBox5, 4, 0);
            tableLayoutPanel1.Controls.Add(textBox4, 3, 0);
            tableLayoutPanel1.Controls.Add(textBox3, 2, 0);
            tableLayoutPanel1.Controls.Add(textBox2, 1, 0);
            tableLayoutPanel1.Controls.Add(textBox1, 0, 0);
            tableLayoutPanel1.Location = new Point(164, 38);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 9;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111107F));
            tableLayoutPanel1.Size = new Size(475, 328);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(5, 5);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(47, 23);
            textBox1.TabIndex = 0;
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(60, 5);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(39, 23);
            textBox2.TabIndex = 1;
            textBox2.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(107, 5);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(43, 23);
            textBox3.TabIndex = 2;
            textBox3.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(159, 5);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(43, 23);
            textBox4.TabIndex = 3;
            textBox4.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(211, 5);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(43, 23);
            textBox5.TabIndex = 4;
            textBox5.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(263, 5);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(43, 23);
            textBox6.TabIndex = 5;
            textBox6.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(315, 5);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(43, 23);
            textBox7.TabIndex = 6;
            textBox7.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(367, 5);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(43, 23);
            textBox8.TabIndex = 7;
            textBox8.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(419, 5);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(43, 23);
            textBox9.TabIndex = 8;
            textBox9.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(5, 41);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(43, 23);
            textBox10.TabIndex = 9;
            textBox10.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(60, 41);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(39, 23);
            textBox11.TabIndex = 10;
            textBox11.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(107, 41);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(43, 23);
            textBox12.TabIndex = 11;
            textBox12.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(159, 41);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(43, 23);
            textBox13.TabIndex = 12;
            textBox13.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(211, 41);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(43, 23);
            textBox14.TabIndex = 13;
            textBox14.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox15
            // 
            textBox15.Location = new Point(263, 41);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(43, 23);
            textBox15.TabIndex = 14;
            textBox15.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox16
            // 
            textBox16.Location = new Point(315, 41);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(43, 23);
            textBox16.TabIndex = 15;
            textBox16.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox17
            // 
            textBox17.Location = new Point(367, 41);
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(43, 23);
            textBox17.TabIndex = 16;
            textBox17.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox18
            // 
            textBox18.Location = new Point(419, 41);
            textBox18.Name = "textBox18";
            textBox18.Size = new Size(43, 23);
            textBox18.TabIndex = 17;
            textBox18.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox19
            // 
            textBox19.Location = new Point(5, 77);
            textBox19.Name = "textBox19";
            textBox19.Size = new Size(43, 23);
            textBox19.TabIndex = 18;
            textBox19.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox20
            // 
            textBox20.Location = new Point(60, 77);
            textBox20.Name = "textBox20";
            textBox20.Size = new Size(39, 23);
            textBox20.TabIndex = 19;
            textBox20.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox21
            // 
            textBox21.Location = new Point(107, 77);
            textBox21.Name = "textBox21";
            textBox21.Size = new Size(43, 23);
            textBox21.TabIndex = 20;
            textBox21.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox22
            // 
            textBox22.Location = new Point(159, 77);
            textBox22.Name = "textBox22";
            textBox22.Size = new Size(43, 23);
            textBox22.TabIndex = 21;
            textBox22.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox23
            // 
            textBox23.Location = new Point(211, 77);
            textBox23.Name = "textBox23";
            textBox23.Size = new Size(43, 23);
            textBox23.TabIndex = 22;
            textBox23.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox24
            // 
            textBox24.Location = new Point(263, 77);
            textBox24.Name = "textBox24";
            textBox24.Size = new Size(43, 23);
            textBox24.TabIndex = 23;
            textBox24.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox25
            // 
            textBox25.Location = new Point(315, 77);
            textBox25.Name = "textBox25";
            textBox25.Size = new Size(43, 23);
            textBox25.TabIndex = 24;
            textBox25.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox26
            // 
            textBox26.Location = new Point(367, 77);
            textBox26.Name = "textBox26";
            textBox26.Size = new Size(43, 23);
            textBox26.TabIndex = 25;
            textBox26.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox27
            // 
            textBox27.Location = new Point(419, 77);
            textBox27.Name = "textBox27";
            textBox27.Size = new Size(43, 23);
            textBox27.TabIndex = 26;
            textBox27.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox28
            // 
            textBox28.Location = new Point(5, 113);
            textBox28.Name = "textBox28";
            textBox28.Size = new Size(43, 23);
            textBox28.TabIndex = 27;
            textBox28.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox29
            // 
            textBox29.Location = new Point(60, 113);
            textBox29.Name = "textBox29";
            textBox29.Size = new Size(39, 23);
            textBox29.TabIndex = 28;
            textBox29.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox30
            // 
            textBox30.Location = new Point(107, 113);
            textBox30.Name = "textBox30";
            textBox30.Size = new Size(43, 23);
            textBox30.TabIndex = 29;
            textBox30.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox31
            // 
            textBox31.Location = new Point(159, 113);
            textBox31.Name = "textBox31";
            textBox31.Size = new Size(43, 23);
            textBox31.TabIndex = 30;
            textBox31.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox32
            // 
            textBox32.Location = new Point(211, 113);
            textBox32.Name = "textBox32";
            textBox32.Size = new Size(43, 23);
            textBox32.TabIndex = 31;
            textBox32.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox33
            // 
            textBox33.Location = new Point(263, 113);
            textBox33.Name = "textBox33";
            textBox33.Size = new Size(43, 23);
            textBox33.TabIndex = 32;
            textBox33.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox34
            // 
            textBox34.Location = new Point(315, 113);
            textBox34.Name = "textBox34";
            textBox34.Size = new Size(43, 23);
            textBox34.TabIndex = 33;
            textBox34.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox35
            // 
            textBox35.Location = new Point(367, 113);
            textBox35.Name = "textBox35";
            textBox35.Size = new Size(43, 23);
            textBox35.TabIndex = 34;
            textBox35.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox36
            // 
            textBox36.Location = new Point(419, 113);
            textBox36.Name = "textBox36";
            textBox36.Size = new Size(43, 23);
            textBox36.TabIndex = 35;
            textBox36.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox37
            // 
            textBox37.Location = new Point(5, 149);
            textBox37.Name = "textBox37";
            textBox37.Size = new Size(43, 23);
            textBox37.TabIndex = 36;
            textBox37.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox38
            // 
            textBox38.Location = new Point(60, 149);
            textBox38.Name = "textBox38";
            textBox38.Size = new Size(39, 23);
            textBox38.TabIndex = 37;
            textBox38.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox39
            // 
            textBox39.Location = new Point(107, 149);
            textBox39.Name = "textBox39";
            textBox39.Size = new Size(43, 23);
            textBox39.TabIndex = 38;
            textBox39.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox40
            // 
            textBox40.Location = new Point(159, 149);
            textBox40.Name = "textBox40";
            textBox40.Size = new Size(43, 23);
            textBox40.TabIndex = 39;
            textBox40.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox41
            // 
            textBox41.Location = new Point(211, 149);
            textBox41.Name = "textBox41";
            textBox41.Size = new Size(43, 23);
            textBox41.TabIndex = 40;
            textBox41.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox42
            // 
            textBox42.Location = new Point(263, 149);
            textBox42.Name = "textBox42";
            textBox42.Size = new Size(43, 23);
            textBox42.TabIndex = 41;
            textBox42.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox43
            // 
            textBox43.Location = new Point(315, 149);
            textBox43.Name = "textBox43";
            textBox43.Size = new Size(43, 23);
            textBox43.TabIndex = 42;
            textBox43.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox44
            // 
            textBox44.Location = new Point(367, 149);
            textBox44.Name = "textBox44";
            textBox44.Size = new Size(43, 23);
            textBox44.TabIndex = 43;
            textBox44.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox45
            // 
            textBox45.Location = new Point(419, 149);
            textBox45.Name = "textBox45";
            textBox45.Size = new Size(43, 23);
            textBox45.TabIndex = 44;
            textBox45.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox46
            // 
            textBox46.Location = new Point(5, 185);
            textBox46.Name = "textBox46";
            textBox46.Size = new Size(43, 23);
            textBox46.TabIndex = 45;
            textBox46.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox47
            // 
            textBox47.Location = new Point(60, 185);
            textBox47.Name = "textBox47";
            textBox47.Size = new Size(39, 23);
            textBox47.TabIndex = 46;
            textBox47.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox48
            // 
            textBox48.Location = new Point(107, 185);
            textBox48.Name = "textBox48";
            textBox48.Size = new Size(43, 23);
            textBox48.TabIndex = 47;
            textBox48.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox49
            // 
            textBox49.Location = new Point(159, 185);
            textBox49.Name = "textBox49";
            textBox49.Size = new Size(43, 23);
            textBox49.TabIndex = 48;
            textBox49.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox50
            // 
            textBox50.Location = new Point(211, 185);
            textBox50.Name = "textBox50";
            textBox50.Size = new Size(43, 23);
            textBox50.TabIndex = 49;
            textBox50.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox51
            // 
            textBox51.Location = new Point(263, 185);
            textBox51.Name = "textBox51";
            textBox51.Size = new Size(43, 23);
            textBox51.TabIndex = 50;
            textBox51.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox52
            // 
            textBox52.Location = new Point(315, 185);
            textBox52.Name = "textBox52";
            textBox52.Size = new Size(43, 23);
            textBox52.TabIndex = 51;
            textBox52.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox53
            // 
            textBox53.Location = new Point(367, 185);
            textBox53.Name = "textBox53";
            textBox53.Size = new Size(43, 23);
            textBox53.TabIndex = 52;
            textBox53.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox54
            // 
            textBox54.Location = new Point(419, 185);
            textBox54.Name = "textBox54";
            textBox54.Size = new Size(43, 23);
            textBox54.TabIndex = 53;
            textBox54.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox55
            // 
            textBox55.Location = new Point(5, 221);
            textBox55.Name = "textBox55";
            textBox55.Size = new Size(43, 23);
            textBox55.TabIndex = 54;
            textBox55.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox56
            // 
            textBox56.Location = new Point(60, 221);
            textBox56.Name = "textBox56";
            textBox56.Size = new Size(39, 23);
            textBox56.TabIndex = 55;
            textBox56.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox57
            // 
            textBox57.Location = new Point(107, 221);
            textBox57.Name = "textBox57";
            textBox57.Size = new Size(43, 23);
            textBox57.TabIndex = 56;
            textBox57.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox58
            // 
            textBox58.Location = new Point(159, 221);
            textBox58.Name = "textBox58";
            textBox58.Size = new Size(43, 23);
            textBox58.TabIndex = 57;
            textBox58.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox59
            // 
            textBox59.Location = new Point(211, 221);
            textBox59.Name = "textBox59";
            textBox59.Size = new Size(43, 23);
            textBox59.TabIndex = 58;
            textBox59.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox60
            // 
            textBox60.Location = new Point(263, 221);
            textBox60.Name = "textBox60";
            textBox60.Size = new Size(43, 23);
            textBox60.TabIndex = 59;
            textBox60.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox61
            // 
            textBox61.Location = new Point(315, 221);
            textBox61.Name = "textBox61";
            textBox61.Size = new Size(43, 23);
            textBox61.TabIndex = 60;
            textBox61.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox62
            // 
            textBox62.Location = new Point(367, 221);
            textBox62.Name = "textBox62";
            textBox62.Size = new Size(43, 23);
            textBox62.TabIndex = 61;
            textBox62.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox63
            // 
            textBox63.Location = new Point(419, 221);
            textBox63.Name = "textBox63";
            textBox63.Size = new Size(43, 23);
            textBox63.TabIndex = 62;
            textBox63.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox64
            // 
            textBox64.Location = new Point(5, 257);
            textBox64.Name = "textBox64";
            textBox64.Size = new Size(43, 23);
            textBox64.TabIndex = 63;
            textBox64.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox65
            // 
            textBox65.Location = new Point(60, 257);
            textBox65.Name = "textBox65";
            textBox65.Size = new Size(39, 23);
            textBox65.TabIndex = 64;
            textBox65.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox66
            // 
            textBox66.Location = new Point(107, 257);
            textBox66.Name = "textBox66";
            textBox66.Size = new Size(43, 23);
            textBox66.TabIndex = 65;
            textBox66.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox67
            // 
            textBox67.Location = new Point(159, 257);
            textBox67.Name = "textBox67";
            textBox67.Size = new Size(43, 23);
            textBox67.TabIndex = 66;
            textBox67.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox68
            // 
            textBox68.Location = new Point(211, 257);
            textBox68.Name = "textBox68";
            textBox68.Size = new Size(43, 23);
            textBox68.TabIndex = 67;
            textBox68.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox69
            // 
            textBox69.Location = new Point(263, 257);
            textBox69.Name = "textBox69";
            textBox69.Size = new Size(43, 23);
            textBox69.TabIndex = 68;
            textBox69.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox70
            // 
            textBox70.Location = new Point(315, 257);
            textBox70.Name = "textBox70";
            textBox70.Size = new Size(43, 23);
            textBox70.TabIndex = 69;
            textBox70.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox71
            // 
            textBox71.Location = new Point(367, 257);
            textBox71.Name = "textBox71";
            textBox71.Size = new Size(43, 23);
            textBox71.TabIndex = 70;
            textBox71.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox72
            // 
            textBox72.Location = new Point(419, 257);
            textBox72.Name = "textBox72";
            textBox72.Size = new Size(43, 23);
            textBox72.TabIndex = 71;
            textBox72.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox73
            // 
            textBox73.Location = new Point(5, 293);
            textBox73.Name = "textBox73";
            textBox73.Size = new Size(43, 23);
            textBox73.TabIndex = 72;
            textBox73.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox74
            // 
            textBox74.Location = new Point(60, 293);
            textBox74.Name = "textBox74";
            textBox74.Size = new Size(39, 23);
            textBox74.TabIndex = 73;
            textBox74.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox75
            // 
            textBox75.Location = new Point(107, 293);
            textBox75.Name = "textBox75";
            textBox75.Size = new Size(43, 23);
            textBox75.TabIndex = 74;
            textBox75.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox76
            // 
            textBox76.Location = new Point(159, 293);
            textBox76.Name = "textBox76";
            textBox76.Size = new Size(43, 23);
            textBox76.TabIndex = 75;
            textBox76.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox77
            // 
            textBox77.Location = new Point(211, 293);
            textBox77.Name = "textBox77";
            textBox77.Size = new Size(43, 23);
            textBox77.TabIndex = 76;
            textBox77.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox78
            // 
            textBox78.Location = new Point(263, 293);
            textBox78.Name = "textBox78";
            textBox78.Size = new Size(43, 23);
            textBox78.TabIndex = 77;
            textBox78.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox79
            // 
            textBox79.Location = new Point(315, 293);
            textBox79.Name = "textBox79";
            textBox79.Size = new Size(43, 23);
            textBox79.TabIndex = 78;
            textBox79.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox80
            // 
            textBox80.Location = new Point(367, 293);
            textBox80.Name = "textBox80";
            textBox80.Size = new Size(43, 23);
            textBox80.TabIndex = 79;
            textBox80.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox81
            // 
            textBox81.Location = new Point(419, 293);
            textBox81.Name = "textBox81";
            textBox81.Size = new Size(43, 23);
            textBox81.TabIndex = 80;
            textBox81.TextAlign = HorizontalAlignment.Center;
            // 
            // btnGenerar
            // 
            btnGenerar.Location = new Point(366, 385);
            btnGenerar.Name = "btnGenerar";
            btnGenerar.Size = new Size(104, 39);
            btnGenerar.TabIndex = 1;
            btnGenerar.Text = "Generar sudoku";
            btnGenerar.UseVisualStyleBackColor = true;
            btnGenerar.Click += btnGenerar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnGenerar);
            Controls.Add(tableLayoutPanel1);
            Name = "Form1";
            Text = "Form1";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private TextBox textBox81;
        private TextBox textBox80;
        private TextBox textBox79;
        private TextBox textBox78;
        private TextBox textBox77;
        private TextBox textBox76;
        private TextBox textBox75;
        private TextBox textBox74;
        private TextBox textBox73;
        private TextBox textBox72;
        private TextBox textBox71;
        private TextBox textBox70;
        private TextBox textBox69;
        private TextBox textBox68;
        private TextBox textBox67;
        private TextBox textBox66;
        private TextBox textBox65;
        private TextBox textBox64;
        private TextBox textBox63;
        private TextBox textBox62;
        private TextBox textBox61;
        private TextBox textBox60;
        private TextBox textBox59;
        private TextBox textBox58;
        private TextBox textBox57;
        private TextBox textBox56;
        private TextBox textBox55;
        private TextBox textBox54;
        private TextBox textBox53;
        private TextBox textBox52;
        private TextBox textBox51;
        private TextBox textBox50;
        private TextBox textBox49;
        private TextBox textBox48;
        private TextBox textBox47;
        private TextBox textBox46;
        private TextBox textBox45;
        private TextBox textBox44;
        private TextBox textBox43;
        private TextBox textBox42;
        private TextBox textBox41;
        private TextBox textBox40;
        private TextBox textBox39;
        private TextBox textBox38;
        private TextBox textBox37;
        private TextBox textBox36;
        private TextBox textBox35;
        private TextBox textBox34;
        private TextBox textBox33;
        private TextBox textBox32;
        private TextBox textBox31;
        private TextBox textBox30;
        private TextBox textBox29;
        private TextBox textBox28;
        private TextBox textBox27;
        private TextBox textBox26;
        private TextBox textBox25;
        private TextBox textBox24;
        private TextBox textBox23;
        private TextBox textBox22;
        private TextBox textBox21;
        private TextBox textBox20;
        private TextBox textBox19;
        private TextBox textBox18;
        private TextBox textBox17;
        private TextBox textBox16;
        private TextBox textBox15;
        private TextBox textBox14;
        private TextBox textBox13;
        private TextBox textBox12;
        private TextBox textBox11;
        private TextBox textBox10;
        private TextBox textBox9;
        private TextBox textBox8;
        private TextBox textBox7;
        private TextBox textBox6;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Button btnGenerar;
    }
}
